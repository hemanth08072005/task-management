from django.contrib import admin
from .models import TaskCreateModel

# Register your models here.

admin.site.register(TaskCreateModel)
